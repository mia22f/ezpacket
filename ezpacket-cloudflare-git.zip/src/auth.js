import { K, getJson, putJson, del } from "./kv.js";

const SESSION_TTL = 7 * 24 * 3600;
const LOGIN_MAX_FAILS = 5;
const LOGIN_WINDOW_SEC = 600;

export const DEFAULT_ADMIN_PASSWORD = "botpanel123";

const K_ADMIN_AUTH = "admin_auth";

export async function sha256hex(str) {
  const buf = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(str),
  );
  return [...new Uint8Array(buf)]
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

export async function safeEqual(a, b) {
  const [ha, hb] = await Promise.all([
    sha256hex(String(a)),
    sha256hex(String(b)),
  ]);
  let diff = 0;
  for (let i = 0; i < ha.length; i++)
    diff |= ha.charCodeAt(i) ^ hb.charCodeAt(i);
  return diff === 0;
}

export function randomToken() {
  const bytes = crypto.getRandomValues(new Uint8Array(32));
  return [...bytes].map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function getPasswordRecord(env) {
  return getJson(env, K_ADMIN_AUTH);
}

const defaultStatusCache = new Map();
export async function isDefaultPasswordActive(env) {
  const rec = await getPasswordRecord(env);
  if (!rec?.hash)
    return (
      !env.ADMIN_PASSWORD ||
      (await safeEqual(env.ADMIN_PASSWORD, DEFAULT_ADMIN_PASSWORD))
    );
  if (typeof rec.defaultPassword === "boolean") return rec.defaultPassword;
  const cacheKey = rec.hash + ":" + (rec.salt || "");
  if (defaultStatusCache.has(cacheKey)) return defaultStatusCache.get(cacheKey);
  const isDefault =
    rec.algorithm === "pbkdf2-sha256" && rec.salt
      ? await safeEqual(
          await passwordHash(DEFAULT_ADMIN_PASSWORD, rec.salt),
          rec.hash,
        )
      : await safeEqual(await sha256hex(DEFAULT_ADMIN_PASSWORD), rec.hash);
  if (defaultStatusCache.size > 64) defaultStatusCache.clear();
  defaultStatusCache.set(cacheKey, isDefault);
  return isDefault;
}
// Compatibility export: an environment variable is never required for initial login.
export async function bootstrapRequired() {
  return false;
}
async function passwordHash(password, salt) {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(password),
    "PBKDF2",
    false,
    ["deriveBits"],
  );
  const hash = await crypto.subtle.deriveBits(
    {
      name: "PBKDF2",
      salt: new TextEncoder().encode(salt),
      iterations: 100000,
      hash: "SHA-256",
    },
    key,
    256,
  );
  return [...new Uint8Array(hash)]
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

export async function setAdminPassword(env, newPassword) {
  const salt = randomToken();
  const hash = await passwordHash(String(newPassword), salt);
  await putJson(env, K_ADMIN_AUTH, {
    hash,
    salt,
    algorithm: "pbkdf2-sha256",
    iterations: 100000,
    defaultPassword: await safeEqual(newPassword, DEFAULT_ADMIN_PASSWORD),
    updatedAt: Date.now(),
  });
}

export async function resetAdminPassword(env) {
  await del(env, K_ADMIN_AUTH);
}

export async function verifyAdminPassword(env, password) {
  const rec = await getPasswordRecord(env);
  if (rec?.algorithm === "pbkdf2-sha256" && rec.salt)
    return safeEqual(await passwordHash(String(password), rec.salt), rec.hash);
  if (rec?.hash) {
    const valid = await safeEqual(await sha256hex(String(password)), rec.hash);
    if (valid) await setAdminPassword(env, password);
    return valid;
  }
  if (await bootstrapRequired(env)) return false;
  const expected = env.ADMIN_PASSWORD || DEFAULT_ADMIN_PASSWORD;
  return safeEqual(String(password), expected);
}

export async function createSession(env, setupOnly = false) {
  const token = randomToken();
  const hash = await sha256hex(token);
  const ttl = setupOnly ? 1800 : SESSION_TTL;
  const expiresAt = Date.now() + ttl * 1000;
  await putJson(
    env,
    K.SESSION(hash),
    { createdAt: Date.now(), expiresAt, setupOnly: !!setupOnly },
    { ttl },
  );
  return { token, expiresAt, requiresPasswordChange: !!setupOnly };
}

export async function validateSession(env, token) {
  if (!token || token.length < 32) return null;
  const s = await getJson(env, K.SESSION(await sha256hex(token)));
  if (!s || !s.expiresAt || s.expiresAt < Date.now()) return null;
  return s;
}

export async function deleteSession(env, token) {
  if (!token) return;
  await del(env, K.SESSION(await sha256hex(token)));
}

export async function deleteAllSessions(env, keepToken) {
  const keepHash = keepToken ? await sha256hex(keepToken) : null;
  let cursor;
  do {
    const res = await env.BOT_KV.list({
      prefix: K.SESSION_PREFIX,
      cursor,
      limit: 1000,
    });
    for (const k of res.keys) {
      const hash = k.name.slice(K.SESSION_PREFIX.length);
      if (hash !== keepHash) await del(env, k.name);
    }
    cursor = res.list_complete ? null : res.cursor;
  } while (cursor);
}

export async function loginAllowed(env, ip) {
  const c = await getJson(env, K.LOGIN_RL(ip));
  return {
    allowed: !c || (c.count || 0) < LOGIN_MAX_FAILS,
    count: (c && c.count) || 0,
  };
}

export async function loginFailed(env, ip) {
  const c = (await getJson(env, K.LOGIN_RL(ip))) || { count: 0 };
  await putJson(
    env,
    K.LOGIN_RL(ip),
    { count: c.count + 1 },
    { ttl: LOGIN_WINDOW_SEC },
  );
}

export async function loginSucceeded(env, ip) {
  await del(env, K.LOGIN_RL(ip));
}

export async function requireAuth(c, next) {
  if (c.env.TRUSTED_PARENT_ADMIN === true) {
    c.set("session", { expiresAt: Date.now() + 60000, managed: true });
    c.set("token", "");
    await next();
    return;
  }
  const header = c.req.header("Authorization") || "";
  const token = header.startsWith("Bearer ") ? header.slice(7).trim() : "";
  const session = token ? await validateSession(c.env, token) : null;
  if (!session) return c.json({ ok: false, error: "unauthorized" }, 401);
  if (typeof session.setupOnly !== "boolean") {
    session.setupOnly = await isDefaultPasswordActive(c.env);
    await putJson(c.env, K.SESSION(await sha256hex(token)), session, {
      ttl: Math.max(60, Math.ceil((session.expiresAt - Date.now()) / 1000)),
    });
  }
  const allowedSetupPaths = [
    "/api/auth/session",
    "/api/auth/change-password",
    "/api/auth/logout",
  ];
  if (
    session.setupOnly &&
    !allowedSetupPaths.includes(c.req.path.replace(/\/$/, ""))
  )
    return c.json({ ok: false, error: "password_change_required" }, 403);
  c.set("session", session);
  c.set("token", token);
  await next();
}

export async function upgradeSetupSession(env, token) {
  const key = K.SESSION(await sha256hex(token));
  const session = await getJson(env, key);
  if (!session) return;
  session.setupOnly = false;
  session.expiresAt = Date.now() + SESSION_TTL * 1000;
  await putJson(env, key, session, { ttl: SESSION_TTL });
}
